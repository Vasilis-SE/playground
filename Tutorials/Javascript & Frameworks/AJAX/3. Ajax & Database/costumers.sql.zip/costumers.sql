-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2015 at 06:58 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `costumers`
--
CREATE DATABASE IF NOT EXISTS `costumers` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `costumers`;

-- --------------------------------------------------------

--
-- Table structure for table `costemer`
--

DROP TABLE IF EXISTS `costemer`;
CREATE TABLE IF NOT EXISTS `costemer` (
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `TelephoneNumber` int(10) NOT NULL,
  `Age` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `costemer`
--

INSERT INTO `costemer` (`FirstName`, `LastName`, `Address`, `TelephoneNumber`, `Age`) VALUES
('Nikos', 'Papadopoulos', 'Polixnis 45', 2147483647, 56),
('Maria', 'Ampatzopoulou', 'Konstantinou 32', 654812562, 35),
('Marianthi', 'Swthra', 'Karavasili Gwnia', 2147483647, 22);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
