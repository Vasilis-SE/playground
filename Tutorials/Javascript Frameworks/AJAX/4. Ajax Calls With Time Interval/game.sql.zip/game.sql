-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2015 at 10:47 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `games`
--

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
CREATE TABLE IF NOT EXISTS `game` (
  `AI` int(11) NOT NULL,
  `gameTitle` varchar(70) NOT NULL,
  `gameRelease` text NOT NULL,
  `gameCompany` varchar(35) NOT NULL,
  `gameGenre` varchar(35) NOT NULL,
  `gameImageUrl` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`AI`, `gameTitle`, `gameRelease`, `gameCompany`, `gameGenre`, `gameImageUrl`) VALUES
(1, 'Elder Scrolls: Online', '9/Jun/2015', 'Bethesda', 'MMORPG', 'Elder_Scrolls_Online_cover.png'),
(2, 'Elder Scrolls: Skyrim', '7/Jun/2013', 'Bethesda', 'RPG', 'skyrim.jpg'),
(3, 'Vtm: Bloodlines', '19/Nov/2004', 'Activision', 'Action / RPG', 'vtm_bloodlines.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game`
--
ALTER TABLE `game`
 ADD UNIQUE KEY `gameTitle` (`gameTitle`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
